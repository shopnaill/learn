<?php
$admin = true;
?>


<?php $__env->startSection('content'); ?>

   <div class="container" style=" margin-top: 124px; ">
      <div class="row">
          <a href="<?php echo e(route('admin.courses.create')); ?>" class="btn btn-primary">إضافة</a>
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                 <th scope="col">العنوان</th>
                 <th scope="col">الملف</th>
                 <th scope="col">التحكم</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($course->id); ?></th>
                <td><?php echo e($course->title); ?></td>
                <td><a href="<?php echo e(asset('storage/'.$course->pdf)); ?>">
                   <i class="fas fa-file-pdf fa-lg"></i>
                </a></td>

                <td>
                  <a href="<?php echo e(route('admin.courses.edit',$course->id)); ?>" class="btn btn-info">تعديل</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            </table>
      </div>
 </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/admin/courses/index.blade.php ENDPATH**/ ?>