<footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-sm-6 col-10 m-xs-auto mb-4 mb-md-0 footer-info">
          <a href="index.html">
            <img src="<?php echo e(asset('img/logo.png')); ?>" class="img-fluid">
          </a>
        </div>
        <div class="col-lg-6 col-sm-6 mb-4 mb-md-0 social-links">
          <ul class="list-unstyled">
              <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if(strtolower($social->title) == 'facebook'): ?>
                <li>
                     <a href="<?php echo e($social->link); ?>"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                </li>
                <?php endif; ?>
                <?php if(strtolower($social->title) == 'twitter'): ?>
                <li>
                     <a href="<?php echo e($social->link); ?>"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                </li>
                <?php endif; ?>
                <?php if(strtolower($social->title) == 'instagram'): ?>
                <li>
                     <a href="<?php echo e($social->link); ?>"><i class="fab fa-instagram" aria-hidden="true"></i></a>
                </li>
                <?php endif; ?>
                <?php if(strtolower($social->title) == 'youtube'): ?>
                <li>
                     <a href="<?php echo e($social->link); ?>"><i class="fab fa-youtube" aria-hidden="true"></i></a>
                </li>
                <?php endif; ?>
                <?php if(strtolower($social->title) == 'whatsapp'): ?>
                <li>
                     <a href="<?php echo e($social->link); ?>"><i class="fab fa-whatsapp" aria-hidden="true"></i></a>
                </li>
                <?php endif; ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>
    </div>
    <div class="lower-footer">
      <p> © جميع الحقوق محفوظه ل</p>
      <a href="http://soft.softwarecloud2.com"> Software Cloud 2</a>
      <p>2022</p>
    </div>
  </footer><?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/layouts/footer.blade.php ENDPATH**/ ?>