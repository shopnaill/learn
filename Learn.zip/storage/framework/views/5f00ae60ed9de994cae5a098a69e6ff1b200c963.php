<?php
$slider = App\Models\Slider::first();
$socials = App\Models\SocialLink::get();
?>
<!doctype html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.rtl.min.css"
    integrity="sha384-gXt9imSW0VcJVHezoNQsP+TNrjYXoGcrqBZJpry9zJt8PCQjobwmhMGaDHTASo9N" crossorigin="anonymous">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
  <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>
<body>
    <?php if(!isset($nav)): ?>
     <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(!isset($admin)): ?>
    <?php echo $__env->make('layouts.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
         <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <img src="assets/img/modal.svg" class="img-fluid">
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <input type="text" class="form-control" id="" placeholder="الأسم">
          </div>
          <div class="mb-3">
            <input type="email" class="form-control" id="" placeholder="البريد الإلكتروني">
          </div>
          <div class="mb-3">
            <input type="tel" class="form-control" id="" placeholder="رقم الجوال">
          </div>
        </div>
        <a type="button" class="primary-btn">إرسال</a>
      </div>
    </div>
  </div>

   <?php if(!isset($admin)): ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <?php endif; ?>

  <a href="#" class="back-to-top" style="display: inline;"><i class="fal fa-long-arrow-up" aria-hidden="true"></i></a>

     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
  <script src="<?php echo e(asset('js/fa-pro.js')); ?>"></script>
  <script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/main.js')); ?>"></script>

  <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/layouts/app.blade.php ENDPATH**/ ?>