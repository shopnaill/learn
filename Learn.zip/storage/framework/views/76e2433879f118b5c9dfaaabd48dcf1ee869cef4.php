<?php
$admin = true;
?>


<?php $__env->startSection('content'); ?>

   <div class="container" style=" margin-top: 124px; ">
      <div class="row">

         <div class="col-md-3">
            <div class="card" style="padding: 20px;">
               <div class="card-header">
                  <h3 class="card-title">
                     <a href="<?php echo e(route('admin.slider')); ?>">
                        <i class="fas fa-images"></i>  Sliders
                       </a>
                   </h3>
                   </a>
               </div>
           </div>
         </div>

         <div class="col-md-3">
            <div class="card" style="padding: 20px;">
               <div class="card-header">
                  <h3 class="card-title">
                     <a href="<?php echo e(route('admin.students')); ?>">
                        <i class="fas fa-users"></i>  Student
                       </a>
                   </h3>
                   </a>
               </div>
           </div>
         </div>

          <div class="col-md-3">
            <div class="card" style="padding: 20px;">
               <div class="card-header">
                  <h3 class="card-title">
                     <a href="<?php echo e(route('admin.courses')); ?>">
                        <i class="fas fa-video"></i>   Courses
                       </a>
                   </h3>
                   </a>
               </div>
           </div>
         </div>

         <div class="col-md-3">
            <div class="card" style="padding: 20px;">
               <div class="card-header">
                  <h3 class="card-title">
                     <a href="<?php echo e(route('admin.social')); ?>">
                        <i class="fas fa-link"></i>    Social Links
                       </a>
                   </h3>
                   </a>
               </div>
           </div>
         </div>

          <div class="col-md-3">
            <div class="card" style="padding: 20px;">
               <div class="card-header">
                  <h3 class="card-title">
                     <a href="<?php echo e(route('admin.index_slider')); ?>">
                        <i class="fas fa-images"></i>   Index Slider
                       </a>
                   </h3>
                   </a>
               </div>
           </div>
         </div>

      </div>
 </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/admin/index.blade.php ENDPATH**/ ?>