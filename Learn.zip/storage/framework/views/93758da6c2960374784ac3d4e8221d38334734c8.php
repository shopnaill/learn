    <section id="students" class="students">
      <div class="container">
        <h3 class="title">خريجين الدورات</h3>
        <div class="swiper studentsSwiper">
          <div class="swiper-wrapper">
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide">
              <img src="<?php echo e(asset('storage/' . $student->image)); ?>"  >
              <h6> <?php echo e($student->name); ?></h6>
              <p><?php echo e($student->job_title); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </section>
<?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/students/section.blade.php ENDPATH**/ ?>