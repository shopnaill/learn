<?php
$nav = true;
$admin = true;
?>


<?php $__env->startSection('content'); ?>
  <section class="home">
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-indicators">
          <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button type="button"  aria-current="true" aria-label="Slide 1" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo e($loop->index); ?>" class="<?php echo e($loop->first ? 'active' : ''); ?>"></button>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="carousel-inner">
          <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
          <button onclick="enableMute()" type="button"><i id="volume" class="fal fa-volume-slash"></i></button>
          <video autoplay loop muted id="myVideo" class="d-block w-100">
            <source src="<?php echo e(asset('storage/'.$slider->video)); ?>" type="video/mp4">
             Your browser does not support HTML5 video.
          </video>
          <div class="carousel-caption">
            <h5>
                <?php echo e($slider->title); ?>

            </h5>
            <p>
                <?php echo e($slider->description); ?>

            </p>
            <a class="primary-btn" href="<?php echo e(route('home')); ?>">إنضم الآن</a>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   

      </div>

      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
        data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
        data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
    var vid = document.getElementById("myVideo");
    var btn = document.getElementById("volume")
    function enableMute() {
      if (vid.muted) {
        vid.muted = false;
        btn.classList.remove("fa-volume-slash")
        btn.classList.add("fa-volume-up")
      }
      else {
        vid.muted = true;
        btn.classList.remove("fa-volume-up")
        btn.classList.add("fa-volume-slash")

      }
    }

  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/welcome.blade.php ENDPATH**/ ?>