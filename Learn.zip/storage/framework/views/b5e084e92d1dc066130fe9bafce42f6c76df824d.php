<?php
$admin = true;
?>


<?php $__env->startSection('content'); ?>

   <div class="container" style=" margin-top: 124px; ">
      <div class="row">
          <a href="<?php echo e(route('admin.students.create')); ?>" class="btn btn-primary">إضافة</a>
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">الصورة</th>
                <th scope="col">الاسم</th>
                 <th scope="col">التحكم</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($student->id); ?></th>
                <td><img src="<?php echo e(asset('storage/'.$student->image)); ?>" width="100" height="100"></td>
                <td><?php echo e($student->name); ?></td>
               
                <td>
                  <a href="<?php echo e(route('admin.students.edit',$student->id)); ?>" class="btn btn-info">تعديل</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            </table>
      </div>
 </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/admin/students/index.blade.php ENDPATH**/ ?>