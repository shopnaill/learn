    <section id="courses" class="courses">
      <div class="container">
        <h3 class="title">المسارات المتاحه</h3>
        <div class="swiper coursesSwiper">
          <div class="swiper-wrapper">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide">
             <a id="course-id" course-id="<?php echo e($course->id); ?>">
              <img src="<?php echo e(asset('storage/' . $course->image)); ?>"  >
              <h5><?php echo e($course->title); ?></h5>
              </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </section><?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/courses/section.blade.php ENDPATH**/ ?>