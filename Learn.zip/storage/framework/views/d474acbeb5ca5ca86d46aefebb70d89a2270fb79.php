<?php
$admin = true;
?>


<?php $__env->startSection('content'); ?>

   <div class="container" style=" margin-top: 124px; ">
      <div class="row">
          <form action="<?php echo e(route('admin.courses.update_create')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="col-md-12">
               <div class="card" style="padding: 20px;">
                  <div class="card-header">
                     <h3 class="card-title">
                        <i class="fas fa-images"></i>
                          Courses
                     </h3>
                  </div>
                  <div class="card-body">
                     <div class="form-group">
                        <label for="title">االعنوان</label>
                        <input type="text" name="title" class="form-control" id="title" placeholder="االعنوان" value="<?php echo e(isset($course)?$course->title:''); ?>">
                     </div>
                        <div class="form-group">
                            <label for="description">الوصف</label>
                               <textarea name="description" id="description" cols="30" rows="10" class="form-control"><?php echo e(isset($course)?$course->description:''); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="goals">الأهداف</label>
                               <textarea name="goals" id="goals" cols="30" rows="10" class="form-control"><?php echo e(isset($course)?$course->goals:''); ?></textarea>
                        </div>
                        <div class="form-group">
                           <label for="pdf">الملف</label>
                           <input type="file" name="pdf" class="form-control" id="pdf" accept="application/pdf">
                        </div>


                     <div class="form-group">
                        <label for="image">الصورة</label>
                        <input type="file" name="image" class="form-control" id="image" accept="image/*">
                     </div>
                    
                     <?php if(isset($course)): ?>
                     <input type="hidden" name="id" value="<?php echo e($course->id); ?>">
                     <div class="form-group">
                        <img src="<?php echo e(asset('storage/'.$course->image)); ?>" alt="" style="width: 100px; height: 100px;">
                     </div>
                     <?php endif; ?>
                   
                     <div class="form-group">
                        <button type="submit" class="btn btn-primary">حفظ</button>
                     </div>
                    </div>
                    </div>
                    </form>
      </div>
 </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/admin/courses/form.blade.php ENDPATH**/ ?>