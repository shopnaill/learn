<?php
$admin = true;
?>


<?php $__env->startSection('content'); ?>

   <div class="container" style=" margin-top: 124px; ">
      <div class="row">
          <form action="<?php echo e(route('admin.social.update_create')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="col-md-12">
               <div class="card" style="padding: 20px;">
                  <div class="card-header">
                     <h3 class="card-title">
                        <i class="fas fa-images"></i>
                          Social Links
                     </h3>
                  </div>
                  <div class="card-body">
                     <div class="form-group">
                        <label for="title">الاسم</label>
                        <input type="text" name="title" class="form-control" id="title" placeholder="الاسم" value="<?php echo e(isset($social)?$social->title:''); ?>">
                     </div>
                        <div class="form-group">
                            <label for="link">الرابط</label>
                              <input type="text" name="link" class="form-control" id="link" placeholder="الرابط" value="<?php echo e(isset($social)?$social->link:''); ?>">
                        </div>
                     <?php if(isset($social)): ?>
                     <input type="hidden" name="id" value="<?php echo e($social->id); ?>">
                     <?php endif; ?>
                   
                     <div class="form-group">
                        <button type="submit" class="btn btn-primary">حفظ</button>
                     </div>
                    </div>
                    </div>
                    </form>
      </div>
 </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/admin/social/form.blade.php ENDPATH**/ ?>