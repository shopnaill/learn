   <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <section id="description<?php echo e($course->id); ?>" class="description">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-8">
            <h3 class="title">
                <?php echo e($course->title); ?>

            </h3>
            <p class="right-p">
                <?php echo nl2br($course->description); ?>

            </p>
            <h6>
              <span>في</span> نهاية الدورة ستتمكن من
              <img src="<?php echo e(asset('img/q.svg')); ?>">
            </h6>
            <ul class="list">
                <?php
                  $goals = explode("\n", $course->goals);
                ?>
                <?php $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($goal); ?>

                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <div class="col-md-4 text-center">
            <img src="<?php echo e(asset('storage/' . $course->image)); ?>" class="img-fluid">
          </div>
          <div class="col-12">
            <div class="enroll">
               <a class="primary-btn" download="<?php echo e($course->title); ?>.pdf" href="<?php echo e(asset('storage/'. $course->pdf)); ?>">حمل الملفات
                <i class="fal fa-download"></i>
              </a>
              <br>
              <a class="primary-btn" data-bs-toggle="modal" data-bs-target="#exampleModal">إنضم الآن</a>
            </div>
            <img src="<?php echo e(asset('img/join-now.svg')); ?>" class="enroll-img">
          </div>

        </div>
    </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/mohamed/Downloads/مسارات التعلم/learn/resources/views/courses/description.blade.php ENDPATH**/ ?>