@extends('layouts.app')

@section('content')
  @include('courses.section')
  @include('courses.description')
  @include('students.section')
@endsection
